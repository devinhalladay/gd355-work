function setup() {
  // The Basics
  createCanvas(500, 500);
  background('#171C20');
}

function draw() {
  // Nothing here yet
}
